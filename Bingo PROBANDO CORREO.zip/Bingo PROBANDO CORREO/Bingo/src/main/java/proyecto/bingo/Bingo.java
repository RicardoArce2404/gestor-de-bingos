package proyecto.bingo;

import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.TextAlignment;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.File;
import java.util.List;

/**
 * Esta clase representa un programa para generar cartones de bingo y crear
 * archivos PDF para cada uno.
 */
public final class Bingo {

    private final ArrayList<CartonBingo> cartones = new ArrayList();  // Cartones generados.
    private final ArrayList<Jugador> jugadores = new ArrayList();     // Jugadores registrados.
    private final ArrayList<Integer> numerosLlamados = new ArrayList(); // Numeros llamados

    /**
     * El método principal del programa.
     */
    public Bingo() {
        cargarJugadoresDesdeCSV(); // Cargar jugadores desde el archivo CSV
    }

    /**
     * Inicia el juego de bingo según la configuración elegida por el usuario.
     *
     * @param pScanner Objeto Scanner para la entrada del usuario.
     */
    public void iniciarJuegoDeBingo(Scanner pScanner) {
        System.out.println("Elija la configuración de juego:");
        System.out.println("1. Jugar en X");
        System.out.println("2. Cuatro esquinas");
        System.out.println("3. Cartón lleno");
        System.out.println("4. Jugar en Z");
        System.out.print("Elija una opción: ");
        int configuracionJuego = pScanner.nextInt();
        pScanner.nextLine();

        if (configuracionJuego >= 1 && configuracionJuego <= 4) {
            jugarBingo(configuracionJuego);
        } else {
            System.out.println("Opción no válida. Por favor, elija una configuración de juego válida.");
        }
    }

    /**
     * Realiza el juego de bingo con la configuración especificada.
     *
     * @param pConfiguracionJuego La configuración de juego elegida.
     */
    public void jugarBingo(int pConfiguracionJuego) {
        // Lógica para el juego de bingo
        CartonBingo cartonGanador = null;
        boolean juegoEnCurso = true;

        while (juegoEnCurso) {
            // Generar un número aleatorio y verificar que no se haya llamado antes
            int numeroLlamado;
            do {
                numeroLlamado = generarNumeroAleatorio(1, 75);
            } while (numerosLlamados.contains(numeroLlamado));

            numerosLlamados.add(numeroLlamado); // Agregar el número llamado a la lista

            System.out.println("Número llamado: " + numeroLlamado);

            // Verificar si algún cartón tiene el número llamado
            for (CartonBingo carton : cartones) {
                if (carton.tieneNumero(numeroLlamado)) {
                    System.out.println("Cartón " + carton.getNumeroCarton() + " tiene el número " + numeroLlamado);
                    // Aquí es donde verificamos si el cartón es ganador según la configuración específica
                    if (pConfiguracionJuego == 1 && carton.tieneConfiguracionX(numerosLlamados)) {
                        cartonGanador = carton;
                        juegoEnCurso = false;
                        break;
                    } else if (pConfiguracionJuego == 2 && carton.tieneCuatroEsquinas(numerosLlamados)) {
                        cartonGanador = carton;
                        juegoEnCurso = false;
                        break;
                    } else if (pConfiguracionJuego == 3 && carton.tieneCartonLleno(numerosLlamados)) {
                        cartonGanador = carton;
                        juegoEnCurso = false;
                        break;
                    } else if (pConfiguracionJuego == 4 && carton.tieneConfiguracionZ(numerosLlamados)) {
                        cartonGanador = carton;
                        juegoEnCurso = false;
                        break;
                    }
                }
            }

            if (cartonGanador != null) {
                System.out.println("¡Tenemos un ganador! Cartón " + cartonGanador.getNumeroCarton());
                break;
            }
        }
    }

    /**
     * Envía un cartón de bingo por correo electrónico.
     *
     * @param pScanner Objeto Scanner para la entrada del usuario.
     */
    public void enviarCorreo(Scanner pScanner) {
        System.out.println("Ingrese el correo:");
        String correo = pScanner.nextLine();
        System.out.println("Ingrese la cantidad de cartones (Entre 1 y 5):");
        int cantidad = pScanner.nextInt();
        enviarCartonCorreo("bingolimonense@gmail.com", correo, cantidad);
    }
    
    
    // Genera un número aleatorio en el rango especificado
    /**
     * Genera un número aleatorio en el rango especificado.
     *
     * @param pMin El valor mínimo del rango.
     * @param pMax El valor máximo del rango.
     * @return Un número aleatorio dentro del rango.
     */
    public int generarNumeroAleatorio(int pMin, int pMax) {
        Random random = new Random();
        return random.nextInt(pMax - pMin + 1) + pMin;
    }

    // Método para mostrar la lista de cartones con identificadores
    /**
     * Muestra la lista de cartones disponibles con sus identificadores.
     */
    public void mostrarListaDeCartonesConIdentificadores() {
        System.out.println("Lista de Cartones Disponibles: \n");
        for (int i = 0; i < cartones.size(); i++) {
            CartonBingo carton = cartones.get(i);
            System.out.println("Carton " + (i + 1) + ": Identificador: " + carton.getCodigoUnico());
        }
    }

    /**
     * Genera un código único de tres letras y tres números.
     *
     * @return Un código único en formato String.
     */
    public String generarCodigoUnico() {
        StringBuilder codigo = new StringBuilder();
        Random rand = new Random();

        for (int i = 0; i < 3; i++) {
            char letra = (char) (rand.nextInt(26) + 'A');
            codigo.append(letra);
        }

        for (int i = 0; i < 3; i++) {
            int numero = rand.nextInt(10);
            codigo.append(numero);
        }

        return codigo.toString();
    }

    /**
     * Genera un cartón de bingo con números aleatorios y un código único.
     *
     * @param pCodigoUnico El código único del cartón.
     * @return Un objeto CartonBingo que representa el cartón generado.
     */
    public CartonBingo generarTarjetaDeBingoConCodigoUnico(String pCodigoUnico) {
        int[][] tarjeta = new int[5][5];
        ArrayList<Integer> numerosUtilizados = new ArrayList<>();
        boolean valido = false;
        int tmp = 0;

        for (int i = 0; i <= 4; i++) {
            for (int j = 0; j < 5; j++) {
                while (!valido) {
                    tmp = (int) (Math.random() * 15) + 1 + 15 * i;
                    if (!numerosUtilizados.contains(tmp)) {
                        valido = true;
                        numerosUtilizados.add(tmp);
                    }
                }
                tarjeta[j][i] = tmp;
                valido = false;
            }
        }

        return new CartonBingo(pCodigoUnico, tarjeta);
    }

    /**
     * Crea un archivo PDF para el cartón de bingo.
     *
     * @param pCarton El objeto CartonBingo que representa el cartón.
     * @param pNumeroCarton El número del cartón.
     * @throws MalformedURLException Si la URL de la imagen es incorrecta.
     * @throws FileNotFoundException Si no se puede encontrar la ubicación de
     * destino para el archivo PDF.
     */
    public void crearArchivoPDF(CartonBingo pCarton, int pNumeroCarton) throws MalformedURLException, FileNotFoundException {
        String rutaCarpetaCartones = ".\\Cartones";
        File carpetaCartones = new File(rutaCarpetaCartones);

        if (!carpetaCartones.exists()) {
            carpetaCartones.mkdirs();
        }

        String nombreArchivoPDF = rutaCarpetaCartones + "\\" + pCarton.getCodigoUnico() + ".pdf";

        try {
            PdfWriter writer = new PdfWriter(new FileOutputStream(nombreArchivoPDF));
            PdfDocument pdfDoc = new PdfDocument(writer);

            try (Document doc = new Document(pdfDoc)) {
                Table table = new Table(UnitValue.createPercentArray(new float[]{20, 20, 20, 20, 20}));
                table.setWidth(UnitValue.createPercentValue(100));

                // Agregar encabezados de las columnas
                table.addCell("-             B            -");
                table.addCell("-             I            -");
                table.addCell("-             N          -");
                table.addCell("-             G          -");
                table.addCell("-             O          -");

                // Agregar los números del cartón a la tabla
                for (int[] fila : pCarton.getNumeros()) {
                    for (int numero : fila) {
                        table.addCell(Integer.toString(numero));
                    }
                }

                String rutaImagen = ".\\Bingo.png";
                Image imagen = new Image(ImageDataFactory.create(rutaImagen));
                imagen.setFixedPosition(pdfDoc.getDefaultPageSize().getWidth() - 100, pdfDoc.getDefaultPageSize().getHeight() - 100);
                doc.add(imagen);
                doc.add(new Paragraph("\n"));
                doc.add(new Paragraph("\n"));
                doc.add(new Paragraph("\n"));
                doc.add(table);
                doc.add(new Paragraph("- Identificador: " + pCarton.getCodigoUnico()).setTextAlignment(TextAlignment.RIGHT));
            }

            System.out.println("\n Archivo PDF generado: " + nombreArchivoPDF);
        } catch (IOException e) {
            System.err.println("\n Error al crear el archivo PDF: " + e.getMessage());
        }
    }

    /**
     * Muestra la lista de cartones disponibles.
     */
    public void mostrarListaDeCartones() {
        System.out.println("Lista de Cartones Disponibles: \n");
        for (int i = 0; i < cartones.size(); i++) {
            CartonBingo carton = cartones.get(i);
            System.out.println("Carton : " + (i + 1) + ". Identificador: " + carton.getCodigoUnico());
        }
    }

    /**
     * Busca un cartón por su código único.
     *
     * @param pCodigo El código único del cartón a buscar.
     * @return El objeto CartonBingo si se encuentra, o null si no se encuentra.
     */
    public CartonBingo buscarCartonPorCodigo(String pCodigo) {
        for (CartonBingo carton : cartones) {
            if (carton.getCodigoUnico().equalsIgnoreCase(pCodigo)) {
                return carton;
            }
        }
        return null;
    }

    /**
     * Busca un cartón por su código único y lo muestra en la consola.
     *
     * @param pScanner El objeto Scanner para la entrada del usuario.
     */
    public void buscarYMostrarCarton(Scanner pScanner) {
        System.out.print("Ingrese el identificador del cartón que desea buscar: ");
        String codigo = pScanner.nextLine();

        CartonBingo carton = buscarCartonPorCodigo(codigo);

        // logica para mostrar el carton encontrado en la GUI
    }

    /**
     * Registra un nuevo jugador con nombre, cédula y correo.
     *
     * @param pNombre Nombre del jugador.
     * @param pCedula Cédula del jugador.
     * @param pCorreo Correo electrónico del jugador.
     */
    public void registrarJugador(String pNombre, String pCedula, String pCorreo) {
        // Las validaciones para los parámetros usados en este método se realizan desde la
        // interfaz, al llegar aquí se puede asegurar que los parámetros ya fueron validados.
        Jugador nuevoJugador = new Jugador(pNombre, pCedula, pCorreo);
        jugadores.add(nuevoJugador);
    }

    /**
     * Genera y muestra los cartones de bingo.
     *
     * @param pCantidadCartones Cantidad de cartones a generar.
     * @throws java.net.MalformedURLException
     * @throws java.io.FileNotFoundException
     */
    public void generarCartones(int pCantidadCartones) throws MalformedURLException, FileNotFoundException {
        borrarCartonesAnteriores(); // Elimina los cartones anteriores antes de generar los nuevos.
        // Las validaciones para los parámetros usados en este método se realizan desde la
        // interfaz, al llegar aquí se puede asegurar que los parámetros ya fueron validados.
        // Generar y mostrar la cantidad de cartones especificada
        for (int i = 1; i <= pCantidadCartones; i++) {
            String codigoUnico = generarCodigoUnico();
            CartonBingo carton = generarTarjetaDeBingoConCodigoUnico(codigoUnico);
            cartones.add(carton);
            crearArchivoPDF(carton, i);
        }
    }

    /**
     * Este método borra los archivos de cartones anteriores en una carpeta
     * especificada.
     */
    public void borrarCartonesAnteriores() {
        // Ruta de la carpeta que contiene los cartones anteriores
        String rutaCarpetaCartones = ".\\Cartones";

        // Crear un objeto File para representar la carpeta de cartones
        File carpetaCartones = new File(rutaCarpetaCartones);

        // Obtener una lista de archivos en la carpeta
        File[] archivos = carpetaCartones.listFiles();

        // Verificar si la lista de archivos no es nula
        if (archivos != null) {
            // Iterar a través de los archivos en la carpeta
            for (File archivo : archivos) {
                // Verificar si el archivo es un archivo (no una carpeta)
                if (archivo.isFile()) {
                    // Borrar el archivo
                    archivo.delete();
                }
            }
        }
    }

    /**
     * Carga los jugadores desde un archivo CSV.
     */
    public void cargarJugadoresDesdeCSV() {
        try (BufferedReader reader = new BufferedReader(new FileReader("jugadores.csv"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String nombre = parts[0];
                    String cedula = parts[1];
                    String correo = parts[2];
                    Jugador jugador = new Jugador(nombre, cedula, correo);
                    jugadores.add(jugador);
                }
            }
        } catch (IOException e) {
            System.err.println("Error al cargar los jugadores desde el archivo CSV: " + e.getMessage());
        }
    }

    /**
     * Guarda los jugadores en un archivo CSV.
     */
    public void guardarJugadoresEnCSV() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("jugadores.csv"))) {
            for (Jugador jugador : jugadores) {
                writer.write(jugador.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error al guardar los jugadores en el archivo CSV: " + e.getMessage());
        }
    }

    /**
     * Envía cartones de bingo por correo electrónico.
     *
     * @param pCorreoUsuario El correo del usuario que envía los cartones.
     * @param pCorreoDestinatario El correo del destinatario.
     * @param pCantidad La cantidad de cartones a enviar.
     */
    public void enviarCartonCorreo(String pCorreoUsuario, String pCorreoDestinatario, int pCantidad) {
        Random aleatorio = new Random();
        String[] imagenesBingo = new String[pCantidad];
        for (int i = 0; i < pCantidad; i++) {
            int indiceRandom = aleatorio.nextInt(cartones.size());
            CartonBingo carton = cartones.get(indiceRandom);
            cartones.remove(indiceRandom);
            String ruta = ".\\Cartones\\" + carton.getCodigoUnico() + ".pdf";
            imagenesBingo[i] = ruta;
        }
        CuentaCorreo cuenta = new CuentaCorreo(pCorreoUsuario);
        cuenta.enviarCorreo(pCorreoDestinatario, "Cartones Bingo", "Se adjuntas las imagenes de los cartones que pediste para el bingo", imagenesBingo);
    }

    /**
     * Obtiene la lista de cartones generados.
     *
     * @return La lista de cartones.
     */
    public ArrayList<CartonBingo> getCartones() {
        return cartones;
    }

    /**
     * Obtiene la lista de jugadores registrados.
     *
     * @return La lista de jugadores.
     */
    public ArrayList<Jugador> getJugadores() {
        return jugadores;
    }

    /**
     * Obtiene la lista de números llamados durante el juego.
     *
     * @return La lista de números llamados.
     */
    public ArrayList<Integer> getNumerosLlamados() {
        return numerosLlamados;
    }

    /**
     * Obtiene la lista de cartones disponibles.
     *
     * @return Una lista de objetos CartonBingo.
     */
    public List<CartonBingo> getCartonesDisponibles() {
        return cartones;
    }
}
