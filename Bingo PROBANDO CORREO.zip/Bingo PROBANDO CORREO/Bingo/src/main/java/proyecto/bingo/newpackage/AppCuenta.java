/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.bingo.newpackage;

import java.io.IOException;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import proyecto.bingo.CuentaCorreo;
/**
 *
 * @author usuario
 */
public class AppCuenta {
    public static void main(String args[]) throws MessagingException, NoSuchProviderException, IOException{
       CuentaCorreo cuenta = new CuentaCorreo("bingolimonense@gmail.com");
       cuenta.leerCorreosRecibidos();
    }
}
