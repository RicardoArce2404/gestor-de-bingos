package proyecto.bingo;

import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.TextAlignment;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 * Esta clase representa un programa para generar cartones de bingo y crear
 * archivos PDF para cada uno.
 */
public class Bingo {
  private final ArrayList<CartonBingo> cartones = new ArrayList();  // Cartones generados.
  private final ArrayList<Jugador> jugadores = new ArrayList();     // Jugadores registrados.
  private final ArrayList<Integer> numerosLlamados = new ArrayList();

  /**
   * El método principal del programa.
   */
  public Bingo() {
    cargarJugadoresDesdeCSV(); // Cargar jugadores desde el archivo CSV
  }

  public void iniciarJuegoDeBingo(Scanner scanner) {
    System.out.println("Elija la configuración de juego:");
    System.out.println("1. Jugar en X");
    System.out.println("2. Cuatro esquinas");
    System.out.println("3. Cartón lleno");
    System.out.println("4. Jugar en Z");
    System.out.print("Elija una opción: ");
    int configuracionJuego = scanner.nextInt();
    scanner.nextLine();

    if (configuracionJuego >= 1 && configuracionJuego <= 4) {
      jugarBingo(configuracionJuego);
    } else {
      System.out.println("Opción no válida. Por favor, elija una configuración de juego válida.");
    }
  }

  public void jugarBingo(int configuracionJuego) {
    // Lógica para el juego de bingo
    CartonBingo cartonGanador = null;
    boolean juegoEnCurso = true;

    while (juegoEnCurso) {
      // Generar un número aleatorio y verificar que no se haya llamado antes
      int numeroLlamado;
      do {
        numeroLlamado = generarNumeroAleatorio(1, 75);
      } while (numerosLlamados.contains(numeroLlamado));

      numerosLlamados.add(numeroLlamado); // Agregar el número llamado a la lista

      System.out.println("Número llamado: " + numeroLlamado);

      // Verificar si algún cartón tiene el número llamado
      for (CartonBingo carton : cartones) {
        if (carton.tieneNumero(numeroLlamado)) {
          System.out.println("Cartón " + carton.getNumeroCarton() + " tiene el número " + numeroLlamado);
          // Aquí es donde verificamos si el cartón es ganador según la configuración específica
          if (configuracionJuego == 1 && carton.tieneConfiguracionX()) {
            cartonGanador = carton;
            juegoEnCurso = false;
            break;
          } else if (configuracionJuego == 2 && carton.tieneCuatroEsquinas()) {
            cartonGanador = carton;
            juegoEnCurso = false;
            break;
          } else if (configuracionJuego == 3 && carton.tieneCartonLleno()) {
            cartonGanador = carton;
            juegoEnCurso = false;
            break;
          } else if (configuracionJuego == 4 && carton.tieneConfiguracionZ()) {
            cartonGanador = carton;
            juegoEnCurso = false;
            break;
          }
        }
      }

      if (cartonGanador != null) {
        System.out.println("¡Tenemos un ganador! Cartón " + cartonGanador.getNumeroCarton());
        break;
      }
    }
  }

  public void enviarCorreo(Scanner scanner) {

    System.out.println("Ingrese el correo:");
    String correo = scanner.nextLine();
    System.out.println("Ingrese la cantidad de cartones (Entre 1 y 5):");
    int cantidad = scanner.nextInt();
    enviarCartonCorreo("bingolimonense@gmail.com", correo, cantidad);
  }
  // Genera un número aleatorio en el rango especificado

  public int generarNumeroAleatorio(int min, int max) {
    Random random = new Random();
    return random.nextInt(max - min + 1) + min;
  }

  // Método para mostrar la lista de cartones con identificadores
  public void mostrarListaDeCartonesConIdentificadores() {
    System.out.println("Lista de Cartones Disponibles: \n");
    for (int i = 0; i < cartones.size(); i++) {
      CartonBingo carton = cartones.get(i);
      System.out.println("Carton " + (i + 1) + ": Identificador: " + carton.getCodigoUnico());
    }
  }

  /**
   * Genera un código único de tres letras y tres números.
   *
   * @return Un código único en formato String.
   */
  public String generarCodigoUnico() {
    StringBuilder codigo = new StringBuilder();
    Random rand = new Random();

    for (int i = 0; i < 3; i++) {
      char letra = (char) (rand.nextInt(26) + 'A');
      codigo.append(letra);
    }

    for (int i = 0; i < 3; i++) {
      int numero = rand.nextInt(10);
      codigo.append(numero);
    }

    return codigo.toString();
  }

  /**
   * Genera un cartón de bingo con números aleatorios y un código único.
   *
   * @param codigoUnico El código único del cartón.
   * @return Un objeto CartonBingo que representa el cartón generado.
   */
  public CartonBingo generarTarjetaDeBingoConCodigoUnico(String codigoUnico) {
    int[][] tarjeta = new int[5][5];
    ArrayList<Integer> numerosUtilizados = new ArrayList<>();
    boolean valido = false;
    int tmp = 0;

    for (int i = 0; i <= 4; i++) {
      for (int j = 0; j < 5; j++) {
        while (!valido) {
          tmp = (int) (Math.random() * 15) + 1 + 15 * i;
          if (!numerosUtilizados.contains(tmp)) {
            valido = true;
            numerosUtilizados.add(tmp);
          }
        }
        tarjeta[j][i] = tmp;
        valido = false;
      }
    }

    return new CartonBingo(codigoUnico, tarjeta);
  }

  /**
   * Crea un archivo PDF para el cartón de bingo.
   *
   * @param carton El objeto CartonBingo que representa el cartón.
   * @param numeroCarton El número del cartón.
   * @throws MalformedURLException Si la URL de la imagen es incorrecta.
   * @throws FileNotFoundException Si no se puede encontrar la ubicación de
   * destino para el archivo PDF.
   */
  public void crearArchivoPDF(CartonBingo carton, int numeroCarton) throws MalformedURLException, FileNotFoundException {
    String rutaCarpetaCartones = "C:\\Users\\User\\OneDrive - Estudiantes ITCR\\Escritorio\\TEC\\POO\\Proyecto1\\Bingo\\Cartones";
    File carpetaCartones = new File(rutaCarpetaCartones);

    if (!carpetaCartones.exists()) {
      carpetaCartones.mkdirs();
    }

    String nombreArchivoPDF = rutaCarpetaCartones + "\\" + carton.getCodigoUnico() + ".pdf";

    try {
      PdfWriter writer = new PdfWriter(new FileOutputStream(nombreArchivoPDF));
      PdfDocument pdfDoc = new PdfDocument(writer);

      try (Document doc = new Document(pdfDoc)) {
        Table table = new Table(UnitValue.createPercentArray(new float[]{20, 20, 20, 20, 20}));
        table.setWidth(UnitValue.createPercentValue(100));

        // Agregar encabezados de las columnas
        table.addCell("-             B            -");
        table.addCell("-             I            -");
        table.addCell("-             N          -");
        table.addCell("-             G          -");
        table.addCell("-             O          -");

        // Agregar los números del cartón a la tabla
        for (int[] fila : carton.getNumeros()) {
          for (int numero : fila) {
            table.addCell(Integer.toString(numero));
          }
        }

        String rutaImagen = "C:\\Users\\User\\OneDrive - Estudiantes ITCR\\Escritorio\\TEC\\POO\\Proyecto1\\Bingo\\src\\main\\java\\proyecto\\bingo\\Bingo.png";
        Image imagen = new Image(ImageDataFactory.create(rutaImagen));
        imagen.setFixedPosition(pdfDoc.getDefaultPageSize().getWidth() - 100, pdfDoc.getDefaultPageSize().getHeight() - 100);
        doc.add(imagen);
        doc.add(new Paragraph("\n"));
        doc.add(new Paragraph("\n"));
        doc.add(new Paragraph("\n"));
        doc.add(table);
        doc.add(new Paragraph("- Identificador: " + carton.getCodigoUnico()).setTextAlignment(TextAlignment.RIGHT));
      }

      System.out.println("\n Archivo PDF generado: " + nombreArchivoPDF);
    } catch (IOException e) {
      System.err.println("\n Error al crear el archivo PDF: " + e.getMessage());
    }
  }

  /**
   * Muestra la lista de cartones disponibles.
   */
  public void mostrarListaDeCartones() {
    System.out.println("Lista de Cartones Disponibles: \n");
    for (int i = 0; i < cartones.size(); i++) {
      CartonBingo carton = cartones.get(i);
      System.out.println("Carton : " + (i + 1) + ". Identificador: " + carton.getCodigoUnico());
    }
  }

  /**
   * Busca un cartón por su código único.
   *
   * @param codigo El código único del cartón a buscar.
   * @return El objeto CartonBingo si se encuentra, o null si no se encuentra.
   */
  public CartonBingo buscarCartonPorCodigo(String codigo) {
    for (CartonBingo carton : cartones) {
      if (carton.getCodigoUnico().equalsIgnoreCase(codigo)) {
        return carton;
      }
    }
    return null;
  }

  /**
   * Busca un cartón por su código único y lo muestra en la consola.
   *
   * @param scanner El objeto Scanner para la entrada del usuario.
   */
  public void buscarYMostrarCarton(Scanner scanner) {
    System.out.print("Ingrese el identificador del cartón que desea buscar: ");
    String codigo = scanner.nextLine();

    CartonBingo carton = buscarCartonPorCodigo(codigo);

    // logica para mostrar el carton encontrado en la GUI
  }

  /**
   * Registra un nuevo jugador con nombre, cédula y correo.
   *
   * @param pNombre Nombre del jugador.
   * @param pCedula Cédula del jugador.
   * @param pCorreo Correo electrónico del jugador.
   */
  public void registrarJugador(String pNombre, String pCedula, String pCorreo) {
    // Las validaciones para los parámetros usados en este método se realizan desde la
    // interfaz, al llegar aquí se puede asegurar que los parámetros ya fueron validados.
    Jugador nuevoJugador = new Jugador(pNombre, pCedula, pCorreo);
    jugadores.add(nuevoJugador);
  }

  /**
   * Genera y muestra los cartones de bingo.
   *
   * @param pCantidadCartones Cantidad de cartones a generar.
   * @throws java.net.MalformedURLException
   * @throws java.io.FileNotFoundException
   */
  public void generarCartones(int pCantidadCartones) throws MalformedURLException, FileNotFoundException {
    // Las validaciones para los parámetros usados en este método se realizan desde la
    // interfaz, al llegar aquí se puede asegurar que los parámetros ya fueron validados.
    
    // Generar y mostrar la cantidad de cartones especificada
    for (int i = 1; i <= pCantidadCartones; i++) {
      String codigoUnico = generarCodigoUnico();
      CartonBingo carton = generarTarjetaDeBingoConCodigoUnico(codigoUnico);
      cartones.add(carton);
      crearArchivoPDF(carton, i);
    }
  }

  /**
   * Carga los jugadores desde un archivo CSV.
   */
  public void cargarJugadoresDesdeCSV() {
    try (BufferedReader reader = new BufferedReader(new FileReader("jugadores.csv"))) {
      String line;
      while ((line = reader.readLine()) != null) {
        String[] parts = line.split(",");
        if (parts.length == 3) {
          String nombre = parts[0];
          String cedula = parts[1];
          String correo = parts[2];
          Jugador jugador = new Jugador(nombre, cedula, correo);
          jugadores.add(jugador);
        }
      }
    } catch (IOException e) {
      System.err.println("Error al cargar los jugadores desde el archivo CSV: " + e.getMessage());
    }
  }

  /**
   * Guarda los jugadores en un archivo CSV.
   */
  public void guardarJugadoresEnCSV() {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("jugadores.csv"))) {
      for (Jugador jugador : jugadores) {
        writer.write(jugador.toString());
        writer.newLine();
      }
    } catch (IOException e) {
      System.err.println("Error al guardar los jugadores en el archivo CSV: " + e.getMessage());
    }
  }

  public void enviarCartonCorreo(String correoUsuario, String correoDestinatario, int cantidad) {
    Random aleatorio = new Random();
    String[] imagenesBingo = new String[cantidad];
    for (int i = 0; i < cantidad; i++) {
      int indiceRandom = aleatorio.nextInt(cartones.size());
      CartonBingo carton = cartones.get(indiceRandom);
      cartones.remove(indiceRandom);
      String ruta = "C:\\Users\\User\\OneDrive - Estudiantes ITCR\\Escritorio\\TEC\\POO\\Proyecto1\\Bingo\\Cartones\\" + carton.getCodigoUnico() + ".pdf";
      imagenesBingo[i] = ruta;
    }
    CuentaCorreo cuenta = new CuentaCorreo(correoUsuario);
    cuenta.enviarCorreo(correoDestinatario, "Cartones Bingo", "Se adjuntas las imagenes de los cartones que pediste para el bingo", imagenesBingo);
  }

  public ArrayList<CartonBingo> getCartones() {
    return cartones;
  }
  
  public ArrayList<Jugador> getJugadores() {
    return jugadores;
  }
  
  public ArrayList<Integer> getNumerosLlamados() {
    return numerosLlamados;
  }
}
