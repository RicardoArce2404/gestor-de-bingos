/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.bingo;

/**
 * Representación de un cartón de bingo.
 */
public class CartonBingo {

  private final String codigoUnico;
  private final int[][] numeros;
  private static int numeroCarton = 0;

  /**
   * Constructor de la clase CartonBingo.
   *
   * @param pCodigoUnico El código único del cartón.
   * @param pNumeros La matriz de números del cartón.
   */
  public CartonBingo(String pCodigoUnico, int[][] pNumeros) {
    this.codigoUnico = pCodigoUnico;
    this.numeros = pNumeros;
    CartonBingo.numeroCarton++;
  }

  /**
   * Obtiene el código único del cartón.
   *
   * @return El código único del cartón en formato String.
   */
  public String getCodigoUnico() {
    return codigoUnico;
  }

  /**
   * Obtiene la matriz de números del cartón.
   *
   * @return La matriz de números del cartón.
   */
  public int[][] getNumeros() {
    return numeros;
  }

  public boolean tieneConfiguracionX() {
    // Lógica para verificar si el cartón cumple con la configuración X
    // La configuración X se cumple si se ha marcado al menos un número en cada columna.
    for (int i = 0; i < 5; i++) {
      boolean columnaCompleta = true;
      for (int j = 0; j < 5; j++) {
        if (numeros[j][i] == 0) {
          columnaCompleta = false;
          break;
        }
      }
      if (columnaCompleta) {
        return true; // Se cumple la configuración X
      }
    }
    return false; // No se cumple la configuración X
  }

  public boolean tieneCuatroEsquinas() {
    // Lógica para verificar si el cartón cumple con la configuración de Cuatro Esquinas
    // Cuatro Esquinas se cumple si se han marcado los números en las esquinas.
    return (numeros[0][0] != 0 && numeros[0][4] != 0 && numeros[4][0] != 0 && numeros[4][4] != 0);
  }

  public boolean tieneCartonLleno() {
    // Lógica para verificar si el cartón está lleno
    // El cartón está lleno si todos los números están marcados.
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        if (numeros[j][i] == 0) {
          return false; // Al menos un número no está marcado
        }
      }
    }
    return true; // Todos los números están marcados, el cartón está lleno
  }

  public boolean tieneConfiguracionZ() {
    // Lógica para verificar si el cartón cumple con la configuración Z
    // La configuración Z se cumple si se ha marcado al menos un número en todas las filas y columnas excepto la central.
    for (int i = 0; i < 5; i++) {
      if (i == 2) {
        continue; // Saltar la fila central
      }
      boolean filaCompleta = true;
      boolean columnaCompleta = true;
      for (int j = 0; j < 5; j++) {
        if (numeros[j][i] == 0) {
          filaCompleta = false;
        }
        if (numeros[i][j] == 0) {
          columnaCompleta = false;
        }
      }
      if (!filaCompleta || !columnaCompleta) {
        return false; // No se cumple la configuración Z
      }
    }
    return true; // Se cumple la configuración Z
  }

  /**
   * Obtiene el número del cartón.
   *
   * @return El número del cartón.
   */
  public int getNumeroCarton() {
    return numeroCarton;
  }

  public boolean tieneNumero(int pNumeroLlamado) {
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        if (numeros[j][i] == pNumeroLlamado) {
          return true;
        }
      }
    }
    return false;
  }
}
