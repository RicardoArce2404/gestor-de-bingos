package proyecto.bingo;

import java.util.List;

/**
 * Representación de un cartón de bingo.
 */
class CartonBingo {

  private final String codigoUnico;
  private final int[][] numeros;
  private static int numeroCarton = 0;

  /**
   * Constructor de la clase CartonBingo.
   *
   * @param codigoUnico El código único del cartón.
   * @param numeros La matriz de números del cartón.
   */
  public CartonBingo(String codigoUnico, int[][] numeros) {
    this.codigoUnico = codigoUnico;
    this.numeros = numeros;
    CartonBingo.numeroCarton++;
  }

  /**
   * Obtiene el código único del cartón.
   *
   * @return El código único del cartón en formato String.
   */
  public String getCodigoUnico() {
    return codigoUnico;
  }

  /**
   * Obtiene la matriz de números del cartón.
   *
   * @return La matriz de números del cartón.
   */
  public int[][] getNumeros() {
    return numeros;
  }

  public boolean tieneConfiguracionX(List<Integer> numerosLlamados) {
    // Lógica para verificar si el cartón cumple con la configuración X
    // La configuración X se cumple si se ha marcado al menos un número en cada columna.
    if (numeros[0][0] != 0 && numeros[0][4] != 0 && numeros[4][0] != 0 && numeros[4][4] != 0 
        && numeros[1][1] != 0  && numeros[1][3] != 0 && numeros[2][2] != 0 && numeros[3][1] != 0 && numeros[3][3] != 0 ) {
      if (numerosLlamados.contains(numeros[0][0]) && numerosLlamados.contains(numeros[0][4])
              && numerosLlamados.contains(numeros[4][0]) && numerosLlamados.contains(numeros[4][4]) 
              && numerosLlamados.contains(numeros[1][1]) && numerosLlamados.contains(numeros[1][3]) 
              && numerosLlamados.contains(numeros[2][2]) && numerosLlamados.contains(numeros[3][1]) && numerosLlamados.contains(numeros[3][3])) {
        return true;
      }
    }
    return false;
  }

  public boolean tieneCuatroEsquinas(List<Integer> numerosLlamados) {
    // Verificar si los números en las cuatro esquinas han sido llamados
    if (numeros[0][0] != 0 && numeros[0][4] != 0 && numeros[4][0] != 0 && numeros[4][4] != 0) {
      if (numerosLlamados.contains(numeros[0][0]) && numerosLlamados.contains(numeros[0][4])
              && numerosLlamados.contains(numeros[4][0]) && numerosLlamados.contains(numeros[4][4])) {
        return true;
      }
    }
    return false;
  }

  public boolean tieneCartonLleno(List<Integer> numerosLlamados) {
    // Lógica para verificar si el cartón está lleno
    // El cartón está lleno si todos los números están marcados.
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        if (numeros[j][i] == 0) {
          return false; // Al menos un número no está marcado
        }
      }
    }
    return true; // Todos los números están marcados, el cartón está lleno
  }

  public boolean tieneConfiguracionZ(List<Integer> numerosLlamados) {
    // Lógica para verificar si el cartón cumple con la configuración Z
    // La configuración Z se cumple si se ha marcado al menos un número en todas las filas y columnas excepto la central.
    for (int i = 0; i < 5; i++) {
      if (i == 2) {
        continue; // Saltar la fila central
      }
      boolean filaCompleta = true;
      boolean columnaCompleta = true;
      for (int j = 0; j < 5; j++) {
        if (numeros[j][i] == 0) {
          filaCompleta = false;
        }
        if (numeros[i][j] == 0) {
          columnaCompleta = false;
        }
      }
      if (!filaCompleta || !columnaCompleta) {
        return false; // No se cumple la configuración Z
      }
    }
    return true; // Se cumple la configuración Z
  }

  /**
   * Obtiene el número del cartón.
   *
   * @return El número del cartón.
   */
  public int getNumeroCarton() {
    return numeroCarton;
  }

  public boolean tieneNumero(int numeroLlamado) {
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        if (numeros[j][i] == numeroLlamado) {
          return true;
        }
      }
    }
    return false;

  }
}
